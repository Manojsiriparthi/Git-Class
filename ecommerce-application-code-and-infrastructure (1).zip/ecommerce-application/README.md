# E-Commerce Application

Production-style e-commerce microservices project.

## Structure
- application-code: frontend and application microservices
- infrastructure: Terraform AWS infrastructure

CI/CD, ECR, analytics, and data-pipeline code are intentionally excluded from this phase.
