
NAT Gateway and RDS are billable. One NAT Gateway per environment is used here to control lab cost. Production HA may require one NAT Gateway per AZ. Use tagging, AWS Budgets, right-sizing, schedules for non-prod, Savings Plans/Reserved Instances where appropriate, and VPC endpoints where they reduce NAT processing.

## Cleanup
Delete the parent stack, not the child stacks individually:
`aws cloudformation delete-stack --stack-name pip-project-dev`
Then repeat for test/prod as needed.
