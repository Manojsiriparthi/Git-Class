#!/bin/bash
set -e
BUCKET=manoj-cloudformation-stack
aws s3 cp child-stacks/network.yaml s3://$BUCKET/child-stacks/network.yaml
aws s3 cp child-stacks/compute.yaml s3://$BUCKET/child-stacks/compute.yaml
aws s3 cp child-stacks/rds.yaml s3://$BUCKET/child-stacks/rds.yaml
echo Uploaded child stacks.
