# Day 4 CloudFormation — Dev/Test/Prod Nested Stack Lab

CloudFormation has no Terraform-style `module` keyword. These reusable YAML files are **child/nested stack templates**. `dev.yaml`, `test.yaml`, and `prod.yaml` are separate parent/entry-point templates.

## Environment layout
- DEV VPC: 10.0.0.0/16
  - Public: 10.0.1.0/24, 10.0.2.0/24
  - Private: 10.0.100.0/24, 10.0.101.0/24
  - EC2: t3.micro; RDS: db.t3.micro
- TEST VPC: 10.20.0.0/16
  - Public: 10.20.1.0/24, 10.20.2.0/24
  - Private: 10.20.100.0/24, 10.20.101.0/24
  - EC2: t3.medium; RDS: db.t3.micro
- PROD VPC: 10.30.0.0/16
  - Public: 10.30.1.0/24, 10.30.2.0/24
  - Private: 10.30.100.0/24, 10.30.101.0/24
  - EC2: t3.large; RDS: db.t3.medium, Multi-AZ, deletion protection
  - RDS master password is managed by Secrets Manager (`ManageMasterUserPassword: true`).

## Credentials
Dev/test intentionally use `adminuser` / `DemoPass8` for demonstration only. Never use those in production.
Prod does not receive a password. RDS generates/manages the master password in Secrets Manager.

## EC2 access
No KeyName and no SSH ingress are configured. The EC2 role has `AmazonSSMManagedInstanceCore`; use Systems Manager Session Manager.

## Deploy
1. Upload child templates:
   `aws s3 cp child-stacks/network.yaml s3://manoj-cloudformation-stack/child-stacks/network.yaml`
   `aws s3 cp child-stacks/compute.yaml s3://manoj-cloudformation-stack/child-stacks/compute.yaml`
   `aws s3 cp child-stacks/rds.yaml s3://manoj-cloudformation-stack/child-stacks/rds.yaml`
2. Replace `YOUR_BUCKET` with `manoj-cloudformation-stack` in the three environment files.
3. Deploy one environment:
   `aws cloudformation create-stack --stack-name pip-project-dev --template-body file://environments/dev.yaml --capabilities CAPABILITY_NAMED_IAM`
4. Watch:
   `aws cloudformation describe-stacks --stack-name pip-project-dev --query 'Stacks[0].StackStatus' --output text`
5. For prod use `pip-project-prod` and `environments/prod.yaml`.

## Cost notes
NAT Gateway and RDS are billable. One NAT Gateway per environment is used here to control lab cost. Production HA may require one NAT Gateway per AZ. Use tagging, AWS Budgets, right-sizing, schedules for non-prod, Savings Plans/Reserved Instances where appropriate, and VPC endpoints where they reduce NAT processing.

## Cleanup
Delete the parent stack, not the child stacks individually:
`aws cloudformation delete-stack --stack-name pip-project-dev`
Then repeat for test/prod as needed.
