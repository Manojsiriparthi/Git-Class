# DAY 4 — CloudFormation Complete Lab

This package covers ALL 8 CloudFormation tasks from the assignment:

1. Network, Compute and Database templates
2. Parameters
3. Mappings
4. Outputs + cross-stack references
5. Root stack + child/nested stacks
6. Change Sets
7. DeletionPolicy / UpdateReplacePolicy
8. Drift detection and remediation

Recommended implementation order:
1. Deploy the root stack using the child templates in S3.
2. Verify Network -> Compute -> Database child stacks.
3. Demonstrate Parameters, Mappings and Outputs.
4. Create and review a Change Set.
5. Demonstrate DeletionPolicy on the RDS resource.
6. Manually change a supported resource property and run drift detection.
7. Remediate the drift by updating the resource back to the template-defined state.

IMPORTANT:
- Upload all child templates to S3 before creating the root stack.
- Replace YOUR_BUCKET in root.yaml.
- Verify AMI IDs for your selected AWS Region before deploying.
- NAT Gateway and RDS can incur AWS charges.
- The database password in this lab is a CloudFormation parameter for learning only. For production, use Secrets Manager.
