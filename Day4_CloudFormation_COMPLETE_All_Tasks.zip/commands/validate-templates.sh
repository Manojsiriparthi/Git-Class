#!/bin/bash
set -e

aws cloudformation validate-template --template-body file://01-network.yaml
aws cloudformation validate-template --template-body file://02-compute.yaml
aws cloudformation validate-template --template-body file://03-database.yaml
aws cloudformation validate-template --template-body file://root.yaml

echo "All templates passed CloudFormation validation."
