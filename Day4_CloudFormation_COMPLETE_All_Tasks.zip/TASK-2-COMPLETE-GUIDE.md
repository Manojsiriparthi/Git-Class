# DAY 4 — COMPLETE STEP-BY-STEP GUIDE

## Task 1 — Three templates

The package has:
- 01-network.yaml
- 02-compute.yaml
- 03-database.yaml

Network creates:
VPC, 2 public subnets, 2 private subnets, Internet Gateway, NAT Gateway and route tables.

Compute creates:
Security Group, Launch Template and Auto Scaling Group.

Database creates:
RDS PostgreSQL, RDS Security Group and DB subnet group.

## Task 2 — Parameters

Parameters are values supplied at deployment time.

Examples:
- Environment
- InstanceType
- DBInstanceClass
- KeyName
- VPC CIDRs

Try deploying root.yaml with:
Environment=dev
InstanceType=t3.micro

Then create a Change Set with InstanceType=t3.small.

## Task 3 — Mappings

02-compute.yaml contains RegionMap.

It chooses an AMI based on AWS Region:
Region -> AMI

IMPORTANT: verify the AMI ID in your selected Region before deployment. AMI IDs change and are region-specific.

Interview:
"Mappings are predefined lookup tables. Parameters are values supplied at deployment time."

## Task 4 — Outputs and cross-stack references

Network exports:
- VPC ID
- Public subnet IDs
- Private subnet IDs

Compute and Database import those values with Fn::ImportValue.

The root stack also reads child stack outputs using GetAtt.

Interview:
"Outputs expose useful stack values. Exports allow other stacks to import those values."

## Task 5 — ROOT + CHILD / NESTED STACKS

THIS IS THE PART THAT WAS MISSING FROM THE EARLIER VERSION.

Architecture:

Root Stack
|
+-- NetworkStack (child)
|     |
|     +-- VPC
|     +-- Subnets
|     +-- IGW
|     +-- NAT
|     +-- Route Tables
|
+-- ComputeStack (child)
|     |
|     +-- Security Group
|     +-- Launch Template
|     +-- ASG
|
+-- DatabaseStack (child)
      |
      +-- RDS
      +-- DB Subnet Group
      +-- DB Security Group

All child templates are referenced by TemplateURL from S3.

### Step-by-step

1. Create an S3 bucket for the CloudFormation templates.
2. Upload:
   01-network.yaml
   02-compute.yaml
   03-database.yaml
3. Edit root.yaml.
4. Replace every:
   https://YOUR_BUCKET.s3.amazonaws.com/
   with your actual bucket name.
5. Upload root.yaml or create the root stack directly using the local file.
6. Create stack named:
   day4-root
7. Provide:
   Environment=dev
   KeyName=<your EC2 key pair>
   InstanceType=t3.micro
   DBInstanceClass=db.t3.micro
   DBName=appdb
   MasterUsername=adminuser
   MasterUserPassword=<temporary lab password>
8. Create stack.
9. Open the root stack -> Resources.
10. You should see:
    NetworkStack
    ComputeStack
    DatabaseStack
11. Click each child stack and verify its resources.

Important:
A nested stack is a CloudFormation stack resource managed by a parent/root stack. Child templates can be reused and independently organized, while the parent controls the overall deployment.

## Task 6 — CHANGE SET

Purpose:
Preview infrastructure changes before applying them.

### Console

1. Open CloudFormation.
2. Open day4-root.
3. Choose Update.
4. Change InstanceType from t3.micro to t3.small.
5. Choose Create change set.
6. Name it:
   day4-instance-change
7. Review Changes.
8. Capture screenshot.
9. Execute the change set if you want to apply it.

Expected:
Modify the compute child stack / Launch Template-related configuration.

Interview:
"A Change Set lets us review the proposed infrastructure changes before executing the update."

## Task 7 — DELETION POLICY

The RDS resource contains:

DeletionPolicy: Snapshot
UpdateReplacePolicy: Snapshot

### Meaning

DeletionPolicy controls what happens to a resource when CloudFormation deletes it from the stack.

For RDS:
Snapshot -> create a final snapshot.

Retain:
Keep the resource after stack deletion.

Delete:
Delete the resource according to normal CloudFormation deletion behavior.

UpdateReplacePolicy controls what happens to the old physical resource when an update requires replacement.

### Demonstration

1. Open 03-database.yaml.
2. Show:
   DeletionPolicy: Snapshot
   UpdateReplacePolicy: Snapshot
3. If intentionally testing deletion, first verify the snapshot/retention behavior.
4. Do not delete production data.

Interview:
"DeletionPolicy controls the behavior of a resource when it is removed from a CloudFormation stack. For RDS I commonly use Snapshot to preserve data."

## Task 8 — DRIFT DETECTION + REMEDIATION

Drift means:
Actual AWS resource configuration != CloudFormation expected configuration.

### Simple lab demonstration

Use a supported resource property that can safely be changed manually.

Example:
1. Deploy the stack.
2. Open the EC2 Security Group created by the compute child stack.
3. Manually add an inbound rule in the console, such as a temporary test rule.
4. Do not modify the CloudFormation template.
5. Go to CloudFormation.
6. Select the relevant child stack: ComputeStack.
7. Choose Detect drift.
8. Wait until drift detection completes.
9. Open drift results.

Expected:
MODIFIED

### Remediation

Option A:
Remove the manual change and return the resource to the template-defined state.

Option B:
If the change is intentional, update the CloudFormation template to contain the desired configuration, then update the stack.

Then run drift detection again.

Expected:
IN_SYNC

Interview:
"Drift detection identifies differences between the actual AWS resource configuration and the CloudFormation template. I remediate by either reverting the manual change or updating the template and redeploying."

## SCREENSHOT CHECKLIST

Capture:

1. Root stack CREATE_COMPLETE
2. Root stack Resources showing NetworkStack, ComputeStack and DatabaseStack
3. Network child stack resources
4. Compute child stack resources
5. Database child stack/RDS
6. Parameters during stack creation/update
7. Network Outputs
8. Cross-stack imported values
9. Change Set preview
10. RDS DeletionPolicy / Snapshot evidence
11. Drift status = MODIFIED
12. Drift remediated = IN_SYNC

## Cleanup

If this is only a lab:
1. Delete root stack first.
2. Confirm child stacks/resources are removed.
3. Check RDS snapshot if DeletionPolicy Snapshot was used.
4. Check NAT Gateway.
5. Check Elastic IP.
6. Check EC2/ASG.
7. Check S3 template bucket if no longer needed.

NAT Gateway and RDS can create charges.
